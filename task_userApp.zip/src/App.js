import React, { useState } from "react";
import "./App.css";
//components
import Header from "./components/Header/Header";
import UserList from "./components/User/UserList";
import AddUser from "./components/User/AddUser";
import EditUser from "./components/User/EditUser";
//react-router
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//mock data
let userRecord = [
  {
    FirstName: "Subham",
    LastName: "Gill",
    Designation: "manager",
    Experience: 3,
    Dob: "12/12/1998",
    id: 1,
    image:
      "https://res.cloudinary.com/webcraze-jan/image/upload/v1584023734/usr.png",
  },
  {
    FirstName: "Peter",
    LastName: "Parker",
    Designation: "CEO",
    Experience: 13,
    Dob: "12/12/1993",
    id: 2,
    image:
      "https://res.cloudinary.com/webcraze-jan/image/upload/v1584023734/glo.jpg",
  },
];

function App() {
  //state
  let [userData, setUserData] = useState(userRecord);

  //handle add
  let handleAddUser = (childData) => {
    console.log(childData);
    setUserData([...userData, childData]);
  };

  //handle delete
  let handleDeleteUser = (childID) => {
    let remaining = userData.filter((item) => item.id !== childID);
    console.log(remaining);
    setUserData(remaining);
  };

  return (
    <div className="App">
      <Router>
        <Header />
        <Switch>
          <Route exact path="/">
            <UserList userData={userData} handleDeleteUser={handleDeleteUser} />
          </Route>
          <Route exact path="/adduser">
            <AddUser handleAddUser={handleAddUser} />
          </Route>
          <Route exact path="/edituser" component={EditUser} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
