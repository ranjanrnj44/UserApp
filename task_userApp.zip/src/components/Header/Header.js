import React from "react";
//router
import { Link } from "react-router-dom";

function Header() {
  return (
    <>
      <nav className="navbar navbar-light bg-light">
        <div className="container">
          <h1 className="display-6 fw-bolder">User_Detail</h1>
          <Link to="/adduser">
            <button className="btn btn-success" type="button">
              Add User
            </button>
          </Link>
        </div>
      </nav>
    </>
  );
}

export default Header;
