import React from "react";
import UserList from "./UserList";

function User({ userData, handleDeleteUser }) {
  return <UserList userData={userData} handleDeleteUser={handleDeleteUser} />;
}

export default User;
